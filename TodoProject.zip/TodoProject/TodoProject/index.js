const db = require('./config/mongoose');
const express = require('express');

const path = require('path');
const port = 8000;
const Contact = require('./models/tasks');
const app = express();

app.set('view engine','ejs');

app.set('views',path.join(__dirname,'views'));
app.use(express.urlencoded());
app.use(express.static('assets'));
var tasks =[
    {
        taskname:"Why not add a Task",
        category:"blah",
        due_date:""
    }
];

app.get('/',function(req,res)
{
    return res.render('home',{
        title:'Todo App',
        name:'Asad',
        Tasks:tasks
    });
});
app.post('/add_task',function(req,res)
{
    tasks.push(req.body);
        //{ taskname:req.body.taskname,
        // category:req.body.category,
        // due_date:req.body.due_date}
    
        console.log(req.body);
    
        Contact.create(
            {taskname:req.body.taskname,
            category:req.body.category,
            due_date:req.body.due_date

        }, function(err,newtask)
        {
            if(err)
            {
                console.log('error in creating a contact!');
                return;
            }
            console.log('********',newtask);
            return res.redirect('back');
            
        });
       return res.redirect('back');
        console.log(req);
    return res.redirect('back');
    console.log(req);
});
app.get('/delete_task',function(req,res)
{
    console.log(req.query);
    let taskname = req.query.taskname;
    let taskIndex = tasks.findIndex(tasks => tasks.taskname == taskname);
    if(taskIndex!=-1)
    {
        tasks.splice(taskIndex,1);
    }
    return res.redirect('back');
});
app.listen(port,function(err)
{
    if(err)
    {
        console.log(err);
        return;
    }
    console.log('server is up and running');   
});